export class Estudiante
{
    nombre: String;
    materias: number;
    matricula: String;
}