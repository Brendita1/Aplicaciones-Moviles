export class Materias{
    materia: String;
    cal: number;
}